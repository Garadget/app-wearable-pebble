#pragma once

void appmessage_init(void);
