#pragma once

// #undef APP_LOG
// #define APP_LOG(...)

enum {
  COMMAND_KEY,
	DEVICE_KEY,
  DEVICES_KEY
};
